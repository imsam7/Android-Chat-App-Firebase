package com.example.airtelsarvesh;

public class User {
    private String name,country,email,password,cpassword;
    private String pno;
    public User(){
    }
    public User(String name, String email,String pno, String country, String password, String cpassword)
    {
        this.name=name;
        this.email=email;
        this.pno=pno;
        this.country=country;
        this.password=password;
        this.cpassword=cpassword;
    }
    public void setName(String name)
    {
        this.name=name;
    }
    public String getName()
    {
        return name;
    }
    public void setEmail(String email)
    {
        this.email=email;
    }
    public String getEmail()
    {
        return email;
    }
    public void setPhone(String pno)
    {
        this.pno=pno;
    }
    public String getPhone()
    {
        return pno;
    }
    public void setCountry(String country)
    {
        this.country=country;
    }
    public String getCountry()
    {
        return country;
    }
    public void setPassword(String password)
    {
        this.password=password;
    }
    public String getPassword()
    {
        return password;
    }
    public void setCpassword(String cpassword)
    {
        this.cpassword=cpassword;
    }
    public String getCpassword()
    {
        return cpassword;
    }
}
