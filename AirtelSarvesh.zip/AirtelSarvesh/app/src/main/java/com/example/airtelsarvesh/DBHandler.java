package com.example.airtelsarvesh;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;

public class DBHandler extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "userDB.db";
    public static final String TABLE_NAME = "User";
    public static final String COLUMN_NAME = "UserName";
    public static final String COLUMN_COUNTRY = "UserCountry";
    public static final String COLUMN_EMAIL = "UserEmail";
    public static final String COLUMN_PHONE= "UserPhone";
    public static final String COLUMN_PASS = "UserPass";
    public static final String COLUMN_CPASS = "UserCpass";
    private String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "(" + COLUMN_NAME + " TEXT, " + COLUMN_COUNTRY + " TEXT, " + COLUMN_EMAIL + " TEXT, " + COLUMN_PHONE + " TEXT, " + COLUMN_PASS + " TEXT, " + COLUMN_CPASS + " TEXT" + ")";

    //initialize the database
    public DBHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }
    /* @Override*/
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {}/*
        public String loadHandler() {}*/
   /*     public void addHandler(User user) {
                ContentValues values = new ContentValues();
                values.put(COLUMN_NAME, user.getName());
                values.put(COLUMN_COUNTRY, user.getCountry());
                values.put(COLUMN_EMAIL, user.getEmail());
                values.put(COLUMN_PHONE, user.getPhone());
                values.put(COLUMN_PASS, user.getPassword());
                values.put(COLUMN_CPASS, user.getCpassword());
                SQLiteDatabase db = this.getWritableDatabase();
                db.insert(TABLE_NAME, null, values);
                db.close();
            }*/
/*        public User findHandler(String studentname) {}
        public boolean deleteHandler(int ID) {}
        public boolean updateHandler(int ID, String name) {}*/

}
